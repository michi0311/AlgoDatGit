package ab1.test;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Random;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Test;

import ab1.Ab1;
import ab1.SelfOrganizingList;
import ab1.SelfOrganizingList.Type;
import ab1.impl.MaroltLiebhartKrainer.Ab1Impl;

public class Tests {

    private Random rand = new Random(System.currentTimeMillis());

    private static Ab1 ab1Impl = new Ab1Impl();

    private static int pts = 0;

    private static int NUM_TESTS = 100;
    private static int[] ARRAY_SIZES_SMALL = { 0, 1, 10, 100, 1000, 10000 };
    private static int[] ARRAY_SIZES_HUGE = { 100000, 1000000, 10000000 };

    @Test
    public void powerMod() {

	int[] base = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
	int[] power = { 1, 11, 111, 1111, 11111, 111111, 1111111, 11111111, 111111111 };
	int[] mod = { 1, 11, 111, 1111, 11111, 111111, 1111111, 11111111, 111111111 };

	for (int b : base) {
	    for (int p : power) {
		for (int m : mod) {
		    BigInteger b2 = BigInteger.valueOf(b);
		    BigInteger p2 = BigInteger.valueOf(p);
		    BigInteger m2 = BigInteger.valueOf(m);

		    int res = b2.modPow(p2, m2).intValue();

		    Assert.assertEquals(res, ab1Impl.powermod(b, p, m));
		}
	    }
	}
	pts += 3;
    }

    @Test
    public void buildHeap1() {
	int[] data = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 15, 16, 17, 18, 19, 20 };
	int[] heap = { 20, 19, 15, 18, 11, 13, 14, 16, 17, 10, 1, 12, 6, 3, 7, 15, 8, 4, 9, 5, 2 };
	ab1Impl.buildHeap(data);
	Assert.assertArrayEquals(heap, data);

	data = new int[] { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
	heap = new int[] { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
	ab1Impl.buildHeap(data);
	Assert.assertArrayEquals(heap, data);

	data = new int[] {};
	heap = new int[] {};
	ab1Impl.buildHeap(data);
	Assert.assertArrayEquals(heap, data);

	data = new int[] { 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
	heap = new int[] { 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
	ab1Impl.buildHeap(data);
	Assert.assertArrayEquals(heap, data);

	data = new int[] { 1, 20, 2, 19, 3, 18, 4, 17, 5, 16, 6, 15, 7, 14, 8, 13, 9, 12, 10, 11 };
	heap = new int[] { 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 6, 2, 7, 4, 8, 1, 9, 5, 10, 3 };
	ab1Impl.buildHeap(data);
	Assert.assertArrayEquals(heap, data);

	pts += 1;
    }

    @Test
    public void buildHeap2() {
	for (int i = 0; i < NUM_TESTS; i++) {
	    for (int size : ARRAY_SIZES_SMALL) {
		int[] arr = getRandomArray(size);
		ab1Impl.buildHeap(arr);

		Assert.assertEquals(true, checkHeapStructure(arr));
	    }
	}

	pts += 1;
    }

    @Test
    public void buildHeap3() {
	for (int i = 0; i < 10; i++) {
	    for (int size : ARRAY_SIZES_HUGE) {
		int[] arr = getRandomArray(size);
		ab1Impl.buildHeap(arr);

		Assert.assertEquals(true, checkHeapStructure(arr));
	    }
	}

	pts += 1;
    }

    private boolean checkHeapStructure(int[] data) {
	for (int i = 1; i <= data.length / 2; i++) {
	    int idx = i - 1;
	    int idx2 = 2 * i - 1;
	    int idx3 = 2 * i;

	    if (data[idx] < data[idx2] || data.length > idx3 && data[idx] < data[idx3]) {
		return false;
	    }
	}
	return true;
    }

    @Test
    public void mergeSortSmall() {
	for (int i = 0; i < NUM_TESTS; i++) {
	    for (int size : ARRAY_SIZES_SMALL) {
		int[] arr = getRandomArray(size);
		int[] arr2 = copyArray(arr);

		ab1Impl.mergeSort(arr);
		Arrays.sort(arr2);

		Assert.assertArrayEquals(arr2, arr);
	    }
	}

	pts += 1;
    }

    @Test
    public void mergeSortHuge() {
	for (int size : ARRAY_SIZES_HUGE) {
	    int[] arr = getRandomArray(size);
	    int[] arr2 = copyArray(arr);

	    ab1Impl.mergeSort(arr);
	    Arrays.sort(arr2);

	    Assert.assertArrayEquals(arr2, arr);
	}

	pts += 2;
    }

    @Test
    public void insertionSort() {
	for (int i = 0; i < NUM_TESTS; i++) {
	    for (int size : ARRAY_SIZES_SMALL) {
		int[] arr = getRandomArray(size);
		int[] arr2 = copyArray(arr);

		ab1Impl.insertionSort(arr);
		Arrays.sort(arr2);

		Assert.assertArrayEquals(arr2, arr);
	    }
	}

	pts += 3;
    }

    @Test
    public void selfOrganizingListNone() {
	SelfOrganizingList list = ab1Impl.getSelfOrganizingList(Type.None);
	Assert.assertArrayEquals(new int[] {}, list.getData());

	// Werte hinzufügen
	list.add(1);
	Assert.assertArrayEquals(new int[] { 1 }, list.getData());

	list.add(2);
	Assert.assertArrayEquals(new int[] { 1, 2 }, list.getData());

	list.add(3);
	Assert.assertArrayEquals(new int[] { 1, 2, 3 }, list.getData());

	list.addAt(4, 0);
	Assert.assertArrayEquals(new int[] { 4, 1, 2, 3 }, list.getData());

	list.addAt(5, 0);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3 }, list.getData());

	list.addAt(6, 2);
	Assert.assertArrayEquals(new int[] { 5, 4, 6, 1, 2, 3 }, list.getData());

	list.addAt(6, 2);
	Assert.assertArrayEquals(new int[] { 5, 4, 6, 6, 1, 2, 3 }, list.getData());

	// Werte lesen, Liste ändert sich nicht

	list.get(1);
	Assert.assertArrayEquals(new int[] { 5, 4, 6, 6, 1, 2, 3 }, list.getData());

	list.get(6);
	Assert.assertArrayEquals(new int[] { 5, 4, 6, 6, 1, 2, 3 }, list.getData());

	list.get(8);
	Assert.assertArrayEquals(new int[] { 5, 4, 6, 6, 1, 2, 3 }, list.getData());

	// alle 6er löschen

	list.removeAll(6);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3 }, list.getData());

	// alle 8er löschen
	list.removeAll(8);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3 }, list.getData());

	// noch Werte hinzufügen
	list.add(7);
	list.add(7);
	list.addAt(7, 0);
	Assert.assertArrayEquals(new int[] { 7, 5, 4, 1, 2, 3, 7, 7 }, list.getData());

	// erstes Vorkommen löschen
	list.removeFirst(7);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3, 7, 7 }, list.getData());

	pts += 1;
    }

    @Test
    public void selfOrganizingListTranspose() {
	SelfOrganizingList list = ab1Impl.getSelfOrganizingList(Type.Transpose);
	Assert.assertArrayEquals(new int[] {}, list.getData());

	// Werte hinzufügen
	list.add(1);
	Assert.assertArrayEquals(new int[] { 1 }, list.getData());

	list.add(2);
	Assert.assertArrayEquals(new int[] { 1, 2 }, list.getData());

	list.add(3);
	Assert.assertArrayEquals(new int[] { 1, 2, 3 }, list.getData());

	list.addAt(4, 0);
	Assert.assertArrayEquals(new int[] { 4, 1, 2, 3 }, list.getData());

	list.addAt(5, 0);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3 }, list.getData());

	list.addAt(6, 2);
	Assert.assertArrayEquals(new int[] { 5, 4, 6, 1, 2, 3 }, list.getData());

	list.addAt(6, 2);
	Assert.assertArrayEquals(new int[] { 5, 4, 6, 6, 1, 2, 3 }, list.getData());

	// Werte lesen

	list.get(1);
	Assert.assertArrayEquals(new int[] { 5, 4, 6, 1, 6, 2, 3 }, list.getData());

	list.get(6);
	Assert.assertArrayEquals(new int[] { 5, 6, 4, 1, 6, 2, 3 }, list.getData());

	list.get(5);
	Assert.assertArrayEquals(new int[] { 5, 6, 4, 1, 6, 2, 3 }, list.getData());

	list.get(8);
	Assert.assertArrayEquals(new int[] { 5, 6, 4, 1, 6, 2, 3 }, list.getData());

	// alle 6er löschen

	list.removeAll(6);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3 }, list.getData());

	// alle 8er löschen
	list.removeAll(8);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3 }, list.getData());

	// noch Werte hinzufügen
	list.add(7);
	list.add(7);
	list.addAt(7, 0);
	Assert.assertArrayEquals(new int[] { 7, 5, 4, 1, 2, 3, 7, 7 }, list.getData());

	// erstes Vorkommen löschen
	list.removeFirst(7);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3, 7, 7 }, list.getData());

	pts += 1;
    }

    @Test
    public void selfOrganizingListFequencyCount() {

	SelfOrganizingList list = ab1Impl.getSelfOrganizingList(Type.FrequencyCount);
	Assert.assertArrayEquals(new int[] {}, list.getData());

	// Werte hinzufügen
	list.add(1);
	Assert.assertArrayEquals(new int[] { 1 }, list.getData());

	list.add(2);
	Assert.assertArrayEquals(new int[] { 1, 2 }, list.getData());

	list.add(3);
	Assert.assertArrayEquals(new int[] { 1, 2, 3 }, list.getData());

	list.addAt(4, 0);
	Assert.assertArrayEquals(new int[] { 4, 1, 2, 3 }, list.getData());

	list.addAt(5, 0);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3 }, list.getData());

	list.addAt(6, 2);
	Assert.assertArrayEquals(new int[] { 5, 4, 6, 1, 2, 3 }, list.getData());

	list.addAt(6, 2);
	Assert.assertArrayEquals(new int[] { 5, 4, 6, 6, 1, 2, 3 }, list.getData());

	// alle 6er löschen
	list.removeAll(6);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3 }, list.getData());

	// alle 8er löschen
	list.removeAll(8);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3 }, list.getData());

	// noch Werte hinzufügen
	list.add(7);
	list.add(7);
	list.addAt(7, 0);
	Assert.assertArrayEquals(new int[] { 7, 5, 4, 1, 2, 3, 7, 7 }, list.getData());

	// erstes Vorkommen löschen
	list.removeFirst(7);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3, 7, 7 }, list.getData());

	list.add(9);
	Assert.assertArrayEquals(new int[] { 5, 4, 1, 2, 3, 7, 7, 9 }, list.getData());

	// Werte lesen

	list.get(1);
	Assert.assertArrayEquals(new int[] { 1, 5, 4, 2, 3, 7, 7, 9 }, list.getData());

	list.get(3);
	Assert.assertArrayEquals(new int[] { 1, 3, 5, 4, 2, 7, 7, 9 }, list.getData());

	list.get(3);
	Assert.assertArrayEquals(new int[] { 3, 1, 5, 4, 2, 7, 7, 9 }, list.getData());

	list.get(5);
	Assert.assertArrayEquals(new int[] { 3, 1, 5, 4, 2, 7, 7, 9 }, list.getData());

	list.get(5);
	Assert.assertArrayEquals(new int[] { 3, 5, 1, 4, 2, 7, 7, 9 }, list.getData());

	list.get(5);
	Assert.assertArrayEquals(new int[] { 5, 3, 1, 4, 2, 7, 7, 9 }, list.getData());

	list.get(9);
	Assert.assertArrayEquals(new int[] { 5, 3, 1, 9, 4, 2, 7, 7 }, list.getData());

	list.get(9);
	Assert.assertArrayEquals(new int[] { 5, 3, 9, 1, 4, 2, 7, 7 }, list.getData());

	list.get(9);
	Assert.assertArrayEquals(new int[] { 5, 9, 3, 1, 4, 2, 7, 7 }, list.getData());

	list.get(9);
	Assert.assertArrayEquals(new int[] { 9, 5, 3, 1, 4, 2, 7, 7 }, list.getData());

	list.get(9);
	Assert.assertArrayEquals(new int[] { 9, 5, 3, 1, 4, 2, 7, 7 }, list.getData());

	list.get(9);
	Assert.assertArrayEquals(new int[] { 9, 5, 3, 1, 4, 2, 7, 7 }, list.getData());

	pts += 1;
    }

    @AfterClass
    public static void printPoints() {
	System.out.println("Punkte: " + pts);
    }

    private int[] getRandomArray(int size) {
	int[] arr = new int[size];
	for (int i = 0; i < size; i++) {
	    arr[i] = rand.nextInt();
	}
	return arr;
    }

    private int[] copyArray(int[] arr) {
	return Arrays.copyOf(arr, arr.length);
    }
}
