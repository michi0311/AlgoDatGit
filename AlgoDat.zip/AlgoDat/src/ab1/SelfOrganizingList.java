package ab1;

public interface SelfOrganizingList {

    /**
     * Fügt einen neuen Wert an das Ende der Liste ein.
     */
    public void add(int value);

    /**
     * Fügt den Wert an die angegebene Stelle der Liste ein. Es wird kein Element hierbei ersetzt oder gelöscht.
     */
    public void addAt(int value, int pos);

    /**
     * Löscht das erste gefundene Element der Liste
     */
    public void removeFirst(int value);

    /**
     * Löscht alle gefundenen Elemente der Liste
     */
    public void removeAll(int value);

    /**
     * Löscht das erste Element der Liste
     */
    public void removeHead();

    /**
     * Liefert den ersten gefunden Knoten der Liste und ordnet die Liste nach der angegebenen Strategie um.
     */
    public DoubleLinkedNode get(int value);

    /**
     * Liefert den ersten Knoten der Liste
     */
    public DoubleLinkedNode getHead();

    /**
     * Liefert den letzten Knoten der Liste
     */
    public DoubleLinkedNode getTail();

    /**
     * Liefert die gespeicherten Daten als Array unter Beibehaltung der Reihenfolge
     */
    public int[] getData();


    public static enum Type {
	/**
	 * Es wird keine Selbstandordnungsstrategie verwendet.
	 */
	None,
	/**
	 * Frequency Count wird als Selbstandordnungsstrategie verwendet.
	 */
	FrequencyCount,
	/**
	 * Tranpose wird als Selbstandordnungsstrategie verwendet.
	 */
	Transpose;
    }
}
