package ab1;

import ab1.SelfOrganizingList.Type;

public interface Ab1 {
    /**
     * Berechnet a^b mod m
     */
    public int powermod(int a, int b, int m);

    /**
     * Erzeugt aus den angegebenen Daten einen (Max-)Heap
     */
    public void buildHeap(int[] data);

    /**
     * Sortiert die Daten mithilfe des Mergesort-Verfahrens
     */
    public void mergeSort(int[] data);

    /**
     * Sortiert die Daten mithilfe des Insertionsort-Verfahrens
     */
    public void insertionSort(int[] data);

    /**
     * Erzeugt eine leere Liste des angegebenen Typs
     */
    public SelfOrganizingList getSelfOrganizingList(Type type);
}
