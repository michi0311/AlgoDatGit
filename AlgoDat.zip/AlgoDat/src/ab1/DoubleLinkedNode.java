package ab1;

public interface DoubleLinkedNode {
    public DoubleLinkedNode getNext();

    public DoubleLinkedNode getPrev();

    public int getData();
}
