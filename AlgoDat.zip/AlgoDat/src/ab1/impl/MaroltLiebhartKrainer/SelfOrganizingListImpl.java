package ab1.impl.MaroltLiebhartKrainer;

import ab1.DoubleLinkedNode;
import ab1.SelfOrganizingList;

public class SelfOrganizingListImpl implements SelfOrganizingList {
    private DoubleLinkedNodeImpl Head;
    private DoubleLinkedNodeImpl Tail;
    private int size;
    Type organizationType;

    public SelfOrganizingListImpl() {
        size = 0;
    }

    class DoubleLinkedNodeImpl implements DoubleLinkedNode {
        private DoubleLinkedNodeImpl nextNode = null;
        private DoubleLinkedNodeImpl prevNode = null;
        private int data;
        private int accesscounter = 0;

        public DoubleLinkedNodeImpl(DoubleLinkedNodeImpl prev, DoubleLinkedNodeImpl next, int data) {
            nextNode = next;
            prevNode = prev;
            this.data = data;
        }

        public DoubleLinkedNodeImpl(int data) {
            this.data = data;
        }

        @Override
        public DoubleLinkedNode getNext() {
            return nextNode;
        }

        public void setNextNode(DoubleLinkedNodeImpl nextNode) {
            this.nextNode = nextNode;
        }

        @Override
        public DoubleLinkedNode getPrev() {
            return prevNode;
        }

        public void setPrevNode(DoubleLinkedNodeImpl prevNode) {
            this.prevNode = prevNode;
        }

        @Override
        public int getData() {
            return data;
        }

        public void increaseCounter(){
            accesscounter++;
        }

        public int getAccesscounter() {
            return accesscounter;
        }
    }

    /**
     * Funktion: ja derzeit alle
     * fügt ein neues Element an das Ende der Liste an
     * @param value Wert
     */
    @Override
    public void add(int value) {
        DoubleLinkedNodeImpl x = new DoubleLinkedNodeImpl(value);
        if (Head == null && Tail == null) {
            Head = x;
            Tail = Head;
            size++;
        } else {
            Tail.setNextNode(x);
            x.setPrevNode(Tail);
            Tail = x;
            size++;
        }
    }

    /**
     * Funktion:
     * erstes: ja
     * mittleres: ja
     * letztes: ja
     *
     * Methode fügt einen Wert an der übergebenen Position ein
     * @param value Wert
     * @param pos position an der der Wert eingefügt werden sollte
     */
    @Override
    public void addAt(int value, int pos) {
        if (pos < 0 || pos > size + 1) return;
        else if (pos == 0) {
            DoubleLinkedNodeImpl newNode = new DoubleLinkedNodeImpl(null,Head,value);
            Head.setPrevNode(newNode);
            Head = newNode;
            size++;
            return;
        } else if (pos == size + 1) {
            DoubleLinkedNodeImpl newNode = new DoubleLinkedNodeImpl(Tail,null, value);
            Tail.setNextNode(newNode);
            Tail = newNode;
            size++;
            return;
        } else {
            DoubleLinkedNodeImpl nextOne = Head;
            for (int i = 1; i <= pos; i++) {
                nextOne = nextOne.nextNode;
            }
            DoubleLinkedNodeImpl previousNode = nextOne.prevNode;
            DoubleLinkedNodeImpl newNode = new DoubleLinkedNodeImpl(previousNode,nextOne,value);
            previousNode.setNextNode(newNode);
            nextOne.setPrevNode(newNode);
            size++;
        }

    }


    /**
     * funktion:
     * erstes: ja
     * mittleres: ja
     * letztes: ja
     *
     * löscht das erste Element wo data = value ist aus der Liste
     *
     * @param value Wert der gelöscht werden sollte
     */
    @Override
    public void removeFirst(int value) {
        for (DoubleLinkedNodeImpl last = Head; last != null ; last = last.nextNode) {
            if (last.data == value) {
                if (last.prevNode == null && last.nextNode == null) {
                    Head = null;
                    size--;
                    return;
                } else if (last.prevNode == null) {
                    Head = last.nextNode;
                    last.nextNode.setPrevNode(null);
                    size--;
                    return;
                } else if (last.nextNode == null) {
                    last.prevNode.setNextNode(null);
                    size--;
                    return;
                } else {
                    last.prevNode.setNextNode(last.nextNode);
                    last.nextNode.setPrevNode(last.prevNode);
                    size--;
                    return;
                }
            }
        }
    }


    /**
     * funktion:
     * erstes: ja
     * mittleres: ja
     * letztes: ja
     *
     * löscht alle Wert wo data = value ist aus der Liste
     *
     * @param value den Wert der Elemente die gelöscht werden sollten
     */
    @Override
    public void removeAll(int value) {
        for (DoubleLinkedNodeImpl last = Head; last != null ; last = last.nextNode) {
            if (last.data == value) {
                if (last.prevNode == null && last.nextNode == null) {
                    Head = null;
                    size--;
                } else if (last.prevNode == null) {
                    Head = last.nextNode;
                    last.nextNode.setPrevNode(null);
                    size--;
                } else if (last.nextNode == null) {
                    last.prevNode.setNextNode(null);
                    size--;
                } else {
                    last.prevNode.setNextNode(last.nextNode);
                    last.nextNode.setPrevNode(last.prevNode);
                    size--;
                }
            }
        }
    }

    @Override
    public void removeHead() {
        if (size <= 1) {
            Head = null;
            Tail = null;
            size = 0;
        } else {
            Head = Head.nextNode;
            Head.setPrevNode(null);
            size--;
        }

    }

    /**
     * None: normale Suchmethoden ohne verschieben
     *
     * Frequency Count: jedes Element hat einen Häufigkeitszähler, der die Anzahl der Zugriffe speichert, Liste wird danach sortiert
     * funktion:
     * erstes: ja
     * zweites: ja
     * mittleres: ja
     * letztes: ja
     *
     *
     * Transpose: Element wird mit Vorgänger vertauscht wenn es gefunden wird
     * funktion:
     * erstes: ja
     * zweites: ja
     * mitte: ja
     * letzte: ja
     *
     * @param value Wert nach dem gesucht wird
     * @return Node
     */
    @Override
    public DoubleLinkedNodeImpl get(int value) {
        if (organizationType == Type.None) {
            for (DoubleLinkedNodeImpl j = Head; j != null ; j = j.nextNode) {
                if (j.data == value) return j;
            }
        } else if (organizationType == Type.FrequencyCount) {
            for (DoubleLinkedNodeImpl j = Head; j != null ; j = j.nextNode) {
                if (j.data == value) {
                    j.increaseCounter();
                    if (j == Head) {
                        return j;
                    } else {
                        for (DoubleLinkedNodeImpl i = j.prevNode; i != null; i = i.prevNode) {
                            if (i.getAccesscounter() >= j.getAccesscounter() || i == Head) {
                                if (j == Tail) {
                                    j.prevNode.setNextNode(null);
                                    Tail = j.prevNode;
                                } else {
                                    j.prevNode.setNextNode(j.nextNode);
                                    j.nextNode.setPrevNode(j.prevNode);
                                }
                                if (i == Head && i.accesscounter < j.accesscounter) {
                                    j.setPrevNode(null);
                                    j.setNextNode(i);
                                    i.setPrevNode(j);
                                    Head = j;
                                }else {
                                    i.nextNode.setPrevNode(j);
                                    j.setNextNode(i.nextNode);
                                    i.setNextNode(j);
                                    j.setPrevNode(i);
                                }
                                return j;
                            }
                        }
                        return j;
                    }
                }
            }
        } else if (organizationType == Type.Transpose) {
            for (DoubleLinkedNodeImpl j = Head; j != null ; j = j.nextNode) {
                if (j.data == value) {
                    if (j.nextNode == null && j.prevNode == null) {
                        return j;
                    } else if (j == Head) {
                        return j;
                    } else if (j == Tail) {
                        DoubleLinkedNodeImpl helper = j.prevNode;
                        helper.prevNode.setNextNode(j);
                        j.setPrevNode(helper.prevNode);
                        helper.setNextNode(null);
                        Tail = helper;
                        helper.setNextNode(j.nextNode);
                        j.setNextNode(helper);
                        helper.setPrevNode(j);
                        return j;
                    } else if (j.prevNode == Head) {
                        DoubleLinkedNodeImpl helper = j.prevNode;
                        j.nextNode.setPrevNode(helper);
                        helper.setNextNode(j.nextNode);
                        j.setPrevNode(null);
                        Head = j;
                        j.setNextNode(helper);
                        helper.setPrevNode(j);
                        return j;
                    } else {
                        DoubleLinkedNodeImpl helper = j.prevNode;
                        helper.prevNode.setNextNode(j);
                        j.setPrevNode(helper.prevNode);
                        j.nextNode.setPrevNode(helper);
                        helper.setNextNode(j.nextNode);
                        j.setNextNode(helper);
                        helper.setPrevNode(j);
                        return j;
                    }
                }
            }
        }
        return null;
    }

    @Override
    public DoubleLinkedNodeImpl getHead() {
        return Head;
    }

    @Override
    public DoubleLinkedNodeImpl getTail() {
        return Tail;
    }

    /**
     * @return int Array mit allen Daten
     */
    @Override
    public int[] getData() {
        int[] out = new int[size];
        int i = 0;
        for (DoubleLinkedNodeImpl j = Head; j != null ; j = j.nextNode) {
            out[i++] = j.data;
        }
        return out;
    }
}
