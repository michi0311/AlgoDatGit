package ab1.impl.MaroltLiebhartKrainer;

import ab1.Ab1;
import ab1.SelfOrganizingList.Type;

public class Ab1Impl implements Ab1 {

    @Override
    public int powermod(int a, int b, int m) {
        long result = 1;
        long base = a;
        while (b > 0) {
            if ((b % 2) == 1) {
                result = (result * base) % m;
            }
            base = (base * base) % m;
            b = b / 2;
        }
        return (int)result;
    }

    @Override
    public void buildHeap(int[] data) {
	// TODO Auto-generated method stub
        for (int i = (data.length / 2) - 1; i >= 0 ; i--) {
            int j = i;
            while((j+1) * 2 - 1 < data.length ) {
                int rightChild = (j + 1) * 2;
                int leftChild = rightChild - 1;
                if (rightChild >= data.length) {
                    if (data[j] < data[leftChild]) {
                        int h = data[j];
                        data[j] = data[leftChild];
                        data[leftChild] = h;
                        j = leftChild;
                    } else break;
                } else {
                    if (data[j] < data[leftChild] || data[j] < data[rightChild]) {
                        if (data[rightChild] < data[leftChild]) {
                            int h = data[j];
                            data[j] = data[leftChild];
                            data[leftChild] = h;
                            j = leftChild;
                        } else {
                            int h = data[j];
                            data[j] = data[rightChild];
                            data[rightChild] = h;
                            j = rightChild;
                        }
                    } else break;
                }
            }
        }
    }

    @Override
    public void mergeSort(int[] data) {
        if (data.length > 1) {
            int middle = (int) Math.round((double)data.length/2);
            int[] firstHalf = new int[middle];
            int[] secondHalf = new int[data.length - middle];
            for (int i = 0; i < middle; i++) {
                firstHalf[i] = data[i];
            }
            for (int i = middle; i < data.length; i++) {
                secondHalf[i-middle] = data[i];
            }
            mergeSort(firstHalf);
            mergeSort(secondHalf);
            merge(data,firstHalf,secondHalf);
        }
    }

    private void merge(int[] data, int[] firstHalf, int[] secondHalf) {
        int i = 0, j = 0, k = 0;
        while (i < firstHalf.length && j < secondHalf.length) {
            if (firstHalf[i] <= secondHalf[j]) {
                data[k++] = firstHalf[i++];
            } else {
                data[k++] = secondHalf[j++];
            }
        }
        while (i < firstHalf.length) {
            data[k++] = firstHalf[i++];
        }
        while (j < secondHalf.length) {
            data[k++] = secondHalf[j++];
        }
    }

    @Override
    public void insertionSort(int[] data) {
        for (int i = 1; i < data.length; i++) {
            int number = data[i];
            int j = i - 1;
            while(j >= 0 && data[j] > number) {
                data[j+1] = data[j--];
            }
            data[j + 1] = number;
        }
    }

    @Override
    public SelfOrganizingListImpl getSelfOrganizingList(Type type) {
            SelfOrganizingListImpl ret = new SelfOrganizingListImpl();
            ret.organizationType = type;
	return ret;
    }
}
