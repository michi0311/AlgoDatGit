package ab2.impl.MaroltLiebhartKrainer;

import ab2.Ab2;
import ab2.AuDQueue;
import ab2.AuDHashSet;
import ab2.AuDSortedTree;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.TreeSet;

/****************************
 * Created by Michael Marolt *
 *****************************/

public class Test {
    public static void main(String[] args) {
        QueueImpl x = new QueueImpl(AuDQueue.Type.LIFO);
        x.enqueue(4);
        x.enqueue(5);
        x.enqueue(6);
        x.enqueue(7);
        x.enqueue(8);
        x.enqueue(9);
        System.out.println(x.dequeue());
        System.out.println(x.dequeue());
        System.out.println(x.dequeue());
        System.out.println(x.dequeue());
        System.out.println(x.dequeue());
        System.out.println(x.dequeue());
        System.out.println(x.dequeue());

        HashSetImpl z = new HashSetImpl(4);
        long lo = 371837322*4576;
        z.add(36);
        System.out.println(z.contains(24));
        z.add(336);
        z.add(3);
        z.add(33);




        System.out.println(Arrays.toString(z.getSet()));

        TreeSet<Integer> set = new TreeSet<>();
        set.add(1);
        set.add(2);
        set.add(5);

        HashSetImpl newh = new HashSetImpl(3);
        newh.add(3);
        newh.add(5);
        newh.add(3);
        System.out.println(Arrays.toString(newh.getSet()));


        System.out.println(set);
        System.out.println();

        int DATA_SIZE = 1_000_000;
        Ab2 impl = new Ab2Impl();
        Random rand = new Random(System.currentTimeMillis());


        AuDHashSet hashSet = impl.emptyHashSet(DATA_SIZE);
        HashSet<Long> hashSetRef = new HashSet<>();

        for (int i = 0; i < DATA_SIZE; i++) {
            long val = rand.nextLong() % DATA_SIZE;

            hashSet.add(val);
            hashSetRef.add(val);

            long val2 = rand.nextLong() % DATA_SIZE;

            if (hashSet.contains(val2) != hashSetRef.contains(val2)) {
                System.out.println(i+" false" + val);
            }
        }
        System.out.println();

        SortedTreeImpl t = new SortedTreeImpl();
        System.out.println(t.add(15));
        System.out.println(t.add(33));
        System.out.println(t.add(44));
        System.out.println(t.add(26));
        System.out.println(t.add(86));
        System.out.println(t.add(72));
        System.out.println(t.add(10));
        System.out.println();
        System.out.println(t.contains(13));
        System.out.println(t.min());
        System.out.println(t.max());
        System.out.println(Arrays.toString(t.toArray(AuDSortedTree.Ordering.LWR)));
        System.out.println(Arrays.toString(t.toArray(AuDSortedTree.Ordering.RWL)));
        System.out.println(Arrays.toString(t.toArray(AuDSortedTree.Ordering.LRW)));
        System.out.println(Arrays.toString(t.toArray(AuDSortedTree.Ordering.RLW)));
        System.out.println(Arrays.toString(t.toArray(AuDSortedTree.Ordering.WLR)));
        System.out.println(Arrays.toString(t.toArray(AuDSortedTree.Ordering.WRL)));
        System.out.println(Arrays.toString(t.getLeafs()));
        t.delete(10);

        System.out.println(Arrays.toString(t.toArray(AuDSortedTree.Ordering.LWR)));
        System.out.println(Arrays.toString(t.toArray(AuDSortedTree.Ordering.WRL)));
    }
}
